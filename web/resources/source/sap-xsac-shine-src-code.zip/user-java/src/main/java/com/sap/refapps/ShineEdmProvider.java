package com.sap.refapps;

import com.sap.gateway.v4.rt.xsa.cds.XSACDSEdmProvider;

public class ShineEdmProvider extends XSACDSEdmProvider{

		
	public ShineEdmProvider() {
		super();
	}

}
